﻿using System;
using System.Collections.Generic;
using System.Threading;

namespace Pong_Ida_Zhang
{
    class Program
    {
        static int timeScale = 30;
        static int playerLength = 8;
        static void Main(string[] args)
        {
            #region DrawStartScreen
            Console.Clear();
            Console.WindowHeight = 30;
            Console.BufferHeight = 30;
            Console.WindowWidth = 100;
            Console.BufferWidth = 100;

            var title = "Pong";

            Console.CursorLeft = Console.BufferWidth / 2 - title.Length / 2;
            Console.WriteLine(title);

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("Player One's Controls: \n\n" +
                "W - Up\n" +
                "S - Down\n");

            var playerTwoControlTitle = "Player Two's Controls:\n";
            var playerTwoControlTitleCursorLeftPosition = Console.BufferWidth - playerTwoControlTitle.Length;
            Console.CursorTop = 1;
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.CursorLeft = playerTwoControlTitleCursorLeftPosition;
            Console.WriteLine(playerTwoControlTitle);
            Console.CursorLeft = playerTwoControlTitleCursorLeftPosition;
            Console.WriteLine("Up Arrow - Up");
            Console.CursorLeft = playerTwoControlTitleCursorLeftPosition;
            Console.WriteLine("Down Arrow - Down");
            Console.ReadKey();
            Console.CursorVisible = false;
            Console.Clear();
            #endregion
            #region InitialGame
            string scoreText = $"{playerOne.Score} : {playerTwo.Score}";
            while (true)
            {
                #endregion
                #region StartGame
                DrawTheScreen();
                while (true)
                {
                    InitialPlayer(playerOne);
                    InitialPlayer(playerTwo);
                    InitialBall();
                    if (playerOne.Score == 3)
                    {
                        Console.Clear();
                        Console.WriteLine("Game Over! Player One Wins!");
                        break;
                    }
                    if (playerTwo.Score == 3)
                    {
                        Console.Clear();
                        Console.WriteLine("Game Over! Player Two Wins!");
                        break;
                    }

                    while (true)
                    {
                        if (Console.KeyAvailable)
                        {
                            var key = Console.ReadKey(true);
                            if (key.Key == ConsoleKey.W)
                            {
                                if (!IsTouchingTop(playerOne))
                                {
                                    playerOne.Direction = -1;
                                    PlayerMovement(playerOne);
                                }
                            }
                            if (key.Key == ConsoleKey.S)
                            {
                                if (!IsTouchingBottom(playerOne))
                                {
                                    playerOne.Direction = 1;
                                    PlayerMovement(playerOne);
                                }
                            }
                            if (key.Key == ConsoleKey.UpArrow)
                            {
                                if (!IsTouchingTop(playerTwo))
                                {
                                    playerTwo.Direction = -1;
                                    PlayerMovement(playerTwo);
                                }
                            }
                            if (key.Key == ConsoleKey.DownArrow)
                            {
                                if (!IsTouchingBottom(playerTwo))
                                {
                                    playerTwo.Direction = 1;
                                    PlayerMovement(playerTwo);
                                }
                            }
                        }
                        Console.Clear();
                        if (ball.Position.X == Console.WindowWidth - 1)
                        {
                            string playerOneWin = "Player One Wins";
                            Console.ForegroundColor = ConsoleColor.White;
                            Console.CursorLeft = Console.WindowWidth / 2 - playerOneWin.Length / 2;
                            Console.CursorTop = 1;
                            Console.WriteLine(playerOneWin);
                            playerOne.Score++;
                            Console.ReadLine();
                            break;
                        }
                        if (ball.Position.X == 0)
                        {
                            string playerTwoWin = "Player Two Wins";
                            Console.ForegroundColor = ConsoleColor.White;
                            Console.CursorLeft = Console.WindowWidth / 2 - playerTwoWin.Length / 2;
                            Console.CursorTop = 1;
                            Console.WriteLine(playerTwoWin);
                            playerTwo.Score++;
                            Console.ReadLine();
                            break;
                        }
                        BallMovement();
                        DrawBall(ball.Position.X, ball.Position.Y, 'F', ConsoleColor.White);
                        DrawPlayer(1, playerOne.Position, '|', ConsoleColor.Yellow);
                        DrawPlayer(Console.WindowWidth - 2, playerTwo.Position, '|', ConsoleColor.Cyan);
                        scoreText = $"{playerOne.Score} : {playerTwo.Score}";
                        Console.SetCursorPosition(Console.WindowWidth / 2 - scoreText.Length / 2 , 0);
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.WriteLine(scoreText);
                        Thread.Sleep(timeScale);
                    }
                }

                Console.ReadLine();
            }
            #endregion


        }
        public static void BallMovement()
        {
            if (ball.Position.Y == Console.WindowHeight - 1 || ball.Position.Y == 0)
            {
                ball.Direction.Y = -ball.Direction.Y;
            }
            if (ball.Position.X == 2 && (ball.Position.Y - playerOne.Position) <= playerLength && (ball.Position.Y - playerOne.Position) >= 0)
            {
                ball.Direction.X = -ball.Direction.X;
            }
            if (ball.Position.X == Console.WindowWidth - 3 && (ball.Position.Y - playerTwo.Position) <= playerLength && (ball.Position.Y - playerTwo.Position) >= 0)
            {
                ball.Direction.X = -ball.Direction.X;
            }
            ball.Position += ball.Direction;
        }
        public struct Vector2 
        {
            public int X;
            public int Y;
            public Vector2(int x, int y)
            {
                this.X = x;
                this.Y = y;
            }
            public static Vector2 operator +(Vector2 v1, Vector2 v2)
            {
                return new Vector2(v1.X + v2.X, v1.Y + v2.Y);
            }
            public static Vector2 operator -(Vector2 v)
            {
                return new Vector2(-v.X, -v.Y);
            }
        }
        public class Ball
        {
            public new Vector2 Position;
            public new Vector2 Direction;
        }
        private static void DrawTheScreen()
        {
            Console.WindowHeight = 30;
            Console.BufferHeight = 30;
            Console.WindowWidth = 100;
            Console.BufferWidth = 100;
            playerOne.Score = 0;
            playerTwo.Score = 0;
        }
        private static void DrawPlayer(int x, int y, char symbol, ConsoleColor color)
        {
            for (int i = 0; i < playerLength; i++)
            {
                Console.SetCursorPosition(x, y + i);
                Console.ForegroundColor = color;
                Console.Write(symbol);
            }
        }
        private static void DrawBall(int x, int y, char symbol, ConsoleColor color)
        {
            Console.SetCursorPosition(x , y);
            Console.ForegroundColor = color;
            Console.Write(symbol);
        }
        public static void InitialPlayer(Player player)
        {
            if (player == playerOne)
            {
                player.Position = Console.WindowHeight / 2 - 5;
            }
            if (player == playerTwo)
            {
                player.Position = Console.WindowHeight / 2 - 5;
            }
        }
        public static void InitialBall()
        {
            ball.Direction = new Vector2(1, 1);
            ball.Position.X = Console.WindowWidth / 2 - 1;
            ball.Position.Y = Console.WindowHeight / 2;
        }
        public static bool IsTouchingBottom(Player player)
        {
            if (player.Position == Console.WindowHeight - playerLength)
            {
                return true;
            }
            else return false;
        }
        public static bool IsTouchingTop(Player player)
        {
            if (player.Position == 0)
            {
                return true;
            }
            else return false;
        }
        public static void PlayerMovement(Player player)
        {
            player.Position += player.Direction;
        }
        public class Player
        {
            public int Position;
            public int Direction;
            public int Score = 0;
            public Dictionary<ConsoleKey, int> InputDirections;
        }
        private static Player playerOne = new Player()
        {
            Position = 1,
            Direction = 0,
            InputDirections = new Dictionary<ConsoleKey, int>()
            {
                {ConsoleKey.W,  -1 },
                {ConsoleKey.S, 1 },
            }
        };
        private static Player playerTwo = new Player()
        {
            Position = Console.WindowWidth - 1,
            Direction = 0,
            InputDirections = new Dictionary<ConsoleKey, int>()
            {
                { ConsoleKey.UpArrow, -1 },
                { ConsoleKey.DownArrow, 1 },
            }
        };
        private static Ball ball = new Ball();
    }
}